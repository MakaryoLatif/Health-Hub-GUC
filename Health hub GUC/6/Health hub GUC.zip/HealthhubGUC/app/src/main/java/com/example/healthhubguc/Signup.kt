package com.example.healthhubguc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class Signup : AppCompatActivity() {
    private lateinit var Email_edt: EditText
    private lateinit var password_edt: EditText
    private lateinit var name_edt: EditText
    private lateinit var btnSignup: Button
    private lateinit var auth : FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_signup)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        auth = FirebaseAuth.getInstance()

        name_edt = findViewById(R.id.name_edt)
        Email_edt = findViewById(R.id.Email_edt)
        password_edt = findViewById(R.id.password_edt)
        btnSignup = findViewById(R.id.btnSignup)

        btnSignup.setOnClickListener{
            val email = Email_edt.text.toString()
            val password = password_edt.text.toString()
            signupfunc(email,password);

        }
    }
    private fun signupfunc(email: String, password: String){
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val intent = Intent(this@Signup,MainActivity::class.java)
                    startActivity(intent)


                } else {
                    Toast.makeText(this@Signup,"try again Error", Toast.LENGTH_SHORT).show()

                }
            }

    }
}